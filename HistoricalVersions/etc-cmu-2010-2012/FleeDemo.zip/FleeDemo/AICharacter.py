
# This class was made for easy calls to the AI and scripting stuff for the 
# Egg objects

#for directx window and functions
import direct.directbase.DirectStart
from pandac.PandaModules import *

#for Actors
from direct.actor.Actor import Actor

#for Pandai
from libpandaai import *

class Character:

    def __init__(self, gameWorld, charno, mass, acc, maxforce):
        #initializing egg character
        self.gameWorld = gameWorld
        self.charno = charno
        
        self.Model = Actor("EggFile/eggCharacter1.egg",{"walk":"EggFile/eggCharacter1_walk.egg",
                                                        "run":"EggFile/eggCharacter1_run.egg"}) 
        self.Model.setScale(0.5)
        self.Model.setPos(-60,0,0)
        self.Model.reparentTo(render)
        self.Model.setPlayRate(1.0, 'walk')
        self.Model.setPlayRate(1.8, 'run')
            
        self.AIchar = AICharacter(charno,self.Model, mass, acc, maxforce)
        self.gameWorld.AIWorld.addAiChar(self.AIchar)
        self.AIbehaviors = self.AIchar.getAiBehaviors()  
        
        self.eggScreamSound = loader.loadSfx("Sounds/eggManScream.wav")
        self.eggScreamSound.setVolume(0.5)

    ###############################SCRIPTING STUFF############################
    def delayStart(self,time):
        taskMgr.doMethodLater(time,self.startSeekLater,"startseekLater")
        
    def startSeekLater(self,task):
        self.seek(self.Target, 0.0) 
        self.walk()

    def distance(self, A, B):
        return((A.getPos(render) - B.getPos(render)).length())

    def proximityCheck(self, target, distance):
        self.Target = target
        self.Target_distance = distance
        self.animControl = target.getAnimControl('turn')
        self.animControl1 = target.getAnimControl('scare')
        taskMgr.add(self.proxChecker,"proxChecker" + str(self.charno))

    # checking the monsters proximity to the eggs
    def proxChecker(self,task):
       
        if(self.distance(self.Target, self.Model) < (self.Target_distance - 1)):
            print(str(self.charno))
            print("fleee awayyyy...1")
            self.Target.lookAt(self.Model)
            self.Target.setH(self.Target.getH() + 180)
            self.fleeAway()
            taskMgr.remove("proxChecker" + str(self.charno))
            
        if((self.animControl1.isPlaying() == True) and (self.distance(self.Target, self.Model) < (self.Target_distance * 2 - 1))):
            self.fleeAwayWOAnim()
            taskMgr.remove("proxChecker" + str(self.charno))
            
        return task.cont

    #to activate the flee
    def fleeAway(self):
        
        #play the animation for the monster turning
        if(self.animControl.isPlaying() == False):
            self.Target.setPlayRate(1, "turn")
            self.Target.play("turn")
            print("fleee awayyyy...1 play anim")
            taskMgr.doMethodLater(0.5,self.animChecker,"animChecker" + str(self.charno)) 
        else:
            taskMgr.add(self.animChecker,"animChecker" + str(self.charno)) 
        
    #to activate the flee
    def fleeAwayWOAnim(self):
        #play the animation for the monster turning
        self.remove(0)
        self.flee(self.Target.getPos(), self.Target_distance * 2, 50.0, 1.0)
        self.run()  
        self.AIchar.setMaxForce(20.0)         
        # might have to change this to be a bit more intelligent
        taskMgr.add(self.fleeChecker, "fleeChecker" + str(self.charno)) 

    #to run the animation sequence correctly and flee after it happens    
    def animChecker(self,task):
        taskMgr.remove("animChecker" + str(self.charno))
        self.Target.stop()
        self.Target.loop("scare")
        self.remove(0)
        self.flee(self.Target.getPos(), self.Target_distance, 50.0, 1.0)
        self.run()  
        self.AIchar.setMaxForce(20.0) 
        self.eggScreamSound.play()        
        taskMgr.doMethodLater(3, self.stopScare, "stopScare" + str(self.charno))
    
    def stopScare(self,task):
        if(self.animControl.isPlaying() == False):
            self.Target.stop()
            self.Target.setPlayRate(-1, 'turn')
            self.Target.play("turn")
        taskMgr.add(self.fleeChecker, "fleeChecker" + str(self.charno)) 
        
    def fleeChecker(self,task):
        if(self.status("flee")):
            taskMgr.remove("fleeChecker" + str(self.charno))
            taskMgr.remove("stopScare" + str(self.charno))
            self.walk()
            taskMgr.add(self.proxChecker,"proxChecker" + str(self.charno))
            self.remove(0)
            self.seek(self.Target.getPos(), 0.0)
            self.AIchar.setMaxForce(10.0)
        
        return task.cont
        
    ######################AI STUFF############################################
            
    def walk(self):
        self.stop()
        self.Model.loop("walk")
        
    def run(self):
        self.stop()
        self.Model.loop("run")
        
    def stop(self):
        self.Model.pose('walk', 0)
        self.Model.stop("walk")
        self.Model.stop("run")
    
    def place(self, pos):
        self.Model.setPos(pos)
    
    def seek(self, target, priority):
        self.AIbehaviors.seek(target,priority)
        
    def pursuit(self, target, priority):
        self.AIbehaviors.pursuit(target,priority)
        
    def flee(self, target, panic_distance, relax_distance, priority):
        self.AIbehaviors.flee(target, panic_distance, relax_distance, priority)
        
    def evade(self, target, panic_distance, relax_distance, priority):
        self.AIbehaviors.evade(target, panic_distance, relax_distance, priority)
        
    def arrival(self, target, arrival_distance, priority):
        self.AIbehaviors.arrival(target, arrival_distance, priority)
        
    def remove(self, value):
        self.AIbehaviors.remove(value)
        
    def status(self, ai_type):
        if(ai_type == "flee"):
            return(self.AIbehaviors.fleeStatus())
    