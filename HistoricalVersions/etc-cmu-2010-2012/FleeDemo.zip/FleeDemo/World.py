

#***********************HEADERS**********************************************
#for directx window and functions
import direct.directbase.DirectStart
from pandac.PandaModules import *
#for directx object support
from direct.showbase.DirectObject import DirectObject
#for intervals
from direct.interval.IntervalGlobal import *
#for FSM
from direct.fsm import FSM
from direct.fsm import State
#for tasks
from direct.task import Task
#for Actors
from direct.actor.Actor import Actor
#for math
import math
import random
#for system commands
import sys
#for directGUI
from direct.gui.DirectGui import *
from direct.gui.OnscreenText import OnscreenText

#My class to reference Pandai ... this does the import libpandai too
from AICharacter import *

#************************GLOBAL**********************************************

speed = 1.0
turnspeed = 2.0

#**********************BASE CLASS (FSM)**************************************

class GameWorld(DirectObject,FSM.FSM):
    def __init__(self, name):
        FSM.FSM.__init__(self, name)
        self.defaultTransitions={'Off':['Game',],'Game':['EndGame',]}
       
        base.cam.setPosHpr(0,-205,50,0,355,0)
        
        self.keyMap = {"left":0, "right":0, "forward":0}
        
        loadingscreen = CardMaker("StartScreen")
        loadingscreen.setFrame(-4/3.0,4/3.0,-1,1)
        
        starttexture = loader.loadTexture("Texture/fleedemo.png")
        self.startnode = NodePath(loadingscreen.generate())
        self.startnode.setTexture(starttexture)
        self.startnode.setTransparency(TransparencyAttrib.MAlpha)
        self.startnode.reparentTo(aspect2d)
        
        #Creating AI World
        self.AIWorld = AIWorld(render)
        

        #Start the world
        self.request("Game")
        
    #*************FSM**************************************************
       
    def enterGame(self):
        #input handling
        self.accept("space",self.startGame)
        self.accept("escape",self.endGame)
        
        #load models
        self.init()
        
        #creating the AICharacters
        self.EGGS = []
        
        #small eggs and big eggs
        for i in range(20):
            if(i<15):
                self.EGGS.append(Character(self, i, 100.0, 0.1, 10.0))
                self.EGGS[i].place(Vec3(-80 + i*10*random.random() ,-90 - i*10*random.random(),0)) 
            else:
                self.EGGS.append(Character(self, i, 100.0, 0.1, 5.0))
                self.EGGS[i].place(Vec3(-80 + i*10*random.random() ,-90 - i*10*random.random(),0)) 
                self.EGGS[i].Model.setScale(0.75)
                self.EGGS[i].Model.setPlayRate(0.5, 'walk')
                self.EGGS[i].Model.setPlayRate(1.5, 'run')

        taskMgr.add(self.AIUpdate,"AIUpdate")
        self.scare_anim = self.Target.getAnimControl('scare')
        self.scare_start = False
        taskMgr.add(self.growlSoundChecker, "growlSoundChecker")
        
    def exitGame(self):
        pass
       
    def enterEndGame(self):
        sys.exit()
        
    def exitEndGame(self):
        pass
        
        
    #*************FUNCTIONS**************************************************

    # to ensure the sound is played only on one detection by the monster
    def growlSoundChecker(self, task):
        
        if(self.scare_anim.isPlaying()==True and self.scare_start == False):
            self.dirnlight.setColor(Vec4(0.5,0.5,0.5,1))
            self.dirnlight1.setColor(Vec4(0.5,0.5,0.5,1))
            self.growlSound.play()
            self.scare_start = True
            
        if(self.scare_start == True and self.scare_anim.isPlaying()==False):
            self.dirnlight.setColor(Vec4(1.0,1.0,1.0,1))
            self.dirnlight1.setColor(Vec4(1.0,1.0,1.0,1))
            self.scare_start = False
        
        return task.cont
    
    def startGame(self):
        self.startnode.hide()
        
        # starting the eggs not at the same time to avoid synchronization
        for i in range(20):
            self.EGGS[i].delayStart(float(i/19.0) * 2)
            if(i<15):
                self.EGGS[i].proximityCheck(self.Target, 60)
            else:
                self.EGGS[i].proximityCheck(self.Target, 40)
                
        self.bgSound.setLoop(True)
        self.bgSound.setVolume(1.0)
        #self.bgSound.play()
      
        
    #to initialize models, lights
    def init(self):
        print("Hello World - init")
        
        self.Enviro = loader.loadModel("EggFile/room");
        self.Enviro.setScale(2.5)
        self.Enviro.reparentTo(render)
                
        self.Basket = loader.loadModel("EggFile/basket2");
        self.Basket.setScale(1.5)
        self.Basket.setPos(3,50,0)
        self.Basket.reparentTo(render)
        
        # Target is the monster in this demo
        self.Target = Actor("EggFile/monster.egg",{"scare":"EggFile/monster_scare.egg", "turn":"EggFile/monster_turn.egg"}) 
        self.Target.setScale(3.0)
        self.Target.setPos(3,50,0)
        self.Target.reparentTo(render)   
        self.Target.pose("turn", 1)  
        
        #lights
        self.dirnlight = DirectionalLight("dirn_light")
        self.dirnlight.setColor(Vec4(1.0,1.0,1.0,1))
        self.dirnlightnode = render.attachNewNode(self.dirnlight)
        self.dirnlightnode.setHpr(45,318,0)
        render.setLight(self.dirnlightnode)
        
        self.dirnlight1 = DirectionalLight("dirn_light1")
        self.dirnlight1.setColor(Vec4(1.0,1.0,1.0,1))
        self.dirnlightnode1 = render.attachNewNode(self.dirnlight1)
        self.dirnlightnode1.setHpr(-45,318,0)
        render.setLight(self.dirnlightnode1)
        
        self.lightNode = NodePath("lightNode")
        self.lightNode.setPos(3,50,10)

        self.PointLight = render.attachNewNode( PointLight( "PointLight" ) )
        self.PointLight.node().setColor( Vec4( 1.0, 0, 0, 1 ) )
        self.PointLight.node().setAttenuation( Vec3( .1, 0.04, 0.0 ) ) 
        render.setLight(self.PointLight)
        
        #sounds
        self.bgSound = loader.loadSfx("Sounds/EggBackgroundMusic1.wav")
        self.growlSound = loader.loadSfx("Sounds/monsterGrowl.wav")
        self.growlSound.setVolume(0.5)
        
    #to update the AIWorld    
    def AIUpdate(self,task):
        self.AIWorld.update()
        return Task.cont
     
    #to end the game    
    def endGame(self):
        self.request("EndGame")
    
world = GameWorld("gameworld")
#messenger.send("r",['from the messenger'])
run()
