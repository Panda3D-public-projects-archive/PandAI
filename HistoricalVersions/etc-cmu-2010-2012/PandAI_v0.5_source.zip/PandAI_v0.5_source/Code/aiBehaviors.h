////////////////////////////////////////////////////////////////////////
//! Filename		: aiBehaviors.cxx
//! Created by	: Deepak, John, Navin
//! Date				:	8 Sep 09
////////////////////////////////////////////////////////////////////////
//!
//! PANDA3D SOFTWARE
//! Copyright(c) Carnegie Mellon University. All rights reserved.
//!
//!	All use of this software is subjest to the terms of the revised BSD
//!	license. You should have received a copy of this license along with this source code in a file named "LICENSE"

////////////////////////////////////////////////////////////////////////

#pragma warning (disable:4996)
#pragma warning (disable:4005)
#pragma warning(disable:4275)

#ifndef _AIBEHAVIORS_H
#define _AIBEHAVIORS_H

#include "globals.h"
#include "aiCharacter.h"

#include "seek.h"
#include "flee.h"
#include "pursue.h"
#include "evade.h"
#include "arrival.h"
#include "flock.h"
#include "wander.h"


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//!
//! Class : AIBehaviors
//! Description : This class implements all the steering behaviors of the AI framework, such as
//!						    seek, flee, pursue, evade, wander and flock. Each steering behavior has a weight which is used when more than
//!								one type of steering behavior is acting on the same ai character. The weight decides the contribution of each
//!								type of steering behavior. The AICharacter class has a handle to an object of this class and this allows to
//!								invoke the steering behaviors via the AICharacter. This class also provides functionality such as pausing, resuming
//!								and removing the AI behaviors of an AI character at anytime.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

class AICharacter;
class Seek;
class Flee;
class Pursue;
class Evade;
class Arrival;
class Flock;
class Wander;

typedef list<Flee, allocator<Flee> > ListFlee;
typedef list<Evade, allocator<Evade> > ListEvade;

class AIBehaviors {

public:
	enum _behavior_type {
			_none = 0x00000,
			_seek = 0x00002,
			_flee = 0x00004,
			_flee_activate = 0x00100,
			_arrival = 0x00008,
			_arrival_activate = 0x01000,
			_wander = 0x00010,
			_pursue = 0x00040,
			_evade = 0x00080,
			_evade_activate = 0x00800,
			_flock = 0x00200,
			_flock_activate = 0x00400
	};

	AICharacter *_ai_char;
	Flock *_flock_group;

	int _behaviors_flags;
	LVecBase3f _steering_force;

	Seek *_seek_obj;
	LVecBase3f _seek_force;

	Flee *_flee_obj;
	LVecBase3f _flee_force;

	//! This list is used if the ai character needs to flee from multiple onjects.
	ListFlee _flee_list;
	ListFlee::iterator _flee_itr;

	Pursue *_pursue_obj;
	LVecBase3f _pursue_force;

    Evade *_evade_obj;
	LVecBase3f _evade_force;

	//! This list is used if the ai character needs to evade from multiple onjects.
	ListEvade _evade_list;
	ListEvade::iterator _evade_itr;

	Arrival *_arrival_obj;
	LVecBase3f _arrival_force;

	//! Since Flock is a collective behavior the variables are declared within the AIBehaviors class.
	float _flock_weight;
	LVecBase3f _flock_force;
	bool _flock_done;

	Wander * _wander_obj;
	LVecBase3f _wander_force;

	bool _conflict, _previous_conflict;

	AIBehaviors();
	~AIBehaviors() {
	}

	bool On(_behavior_type bt)	{
		return (_behaviors_flags & bt) == bt;
	}
	bool Off(_behavior_type bt)	{
		return (_behaviors_flags | bt) == bt;
	}

	void seek_on() {
		_behaviors_flags |= _seek;
	}
	void flee_on() {
		_behaviors_flags |= _flee;
	}
	void flee_activate_on() {
		_behaviors_flags |= _flee_activate;
	}
	void arrival_on() {
		_behaviors_flags |= _arrival;
	}
	void arrival_activate_on() {
		_behaviors_flags |= _arrival_activate;
	}
	void pursue_on() {
		_behaviors_flags |= _pursue;
	}
	void evade_on() {
		_behaviors_flags |= _evade;
	}
	void evade_activate_on() {
		_behaviors_flags |= _evade_activate;
	}
	void flock_on() {
		_behaviors_flags |= _flock;
	}
	void flock_activate_on() {
		_behaviors_flags |= _flock_activate;
	}
	void wander_on() {
		_behaviors_flags |= _wander;
	}

	void seek_off();
	void flee_off();
	void flee_activate_off() {
		if (On(_flee_activate)) _behaviors_flags ^= _flee_activate;
	}
	void arrival_off();
	void arrival_activate_off() {
		if (On(_arrival_activate)) _behaviors_flags ^= _arrival_activate;
	}
	void pursue_off();
	void evade_off();
	void evade_activate_off() {
		if (On(_evade_activate)) _behaviors_flags ^= _evade_activate;
	}
	void flock_off();
	void flock_activate_off() {
		if (On(_flock_activate)) _behaviors_flags ^= _flock_activate;
	}
	void wander_off();

	bool is_off() {
		return Off(_none);
	}
	bool is_seek_on() {
		return On(_seek);
	}
	bool is_flee_on() {
		return On(_flee);
	}
	bool is_flee_activate_on() {
		return On(_flee_activate);
	}
	bool is_arrival_on(){
		return On(_arrival);
	}
	bool is_arrival_activate_on() {
		return On(_arrival_activate);
	}
	bool is_pursue_on() {
		return On(_pursue);
	}
	bool is_evade_on() {
		return On(_evade);
	}
	bool is_evade_activate_on() {
		return On(_evade_activate);
	}
	bool is_flock_on() {
		return On(_flock);
	}
	bool is_flock_activate_on() {
		return On(_flock_activate);
	}
	bool is_wander_on() {
		return On(_wander);
	}

	bool is_conflict();

	void accumulate_force(string force_type, LVecBase3f force);
	LVecBase3f calculate_prioritized();

	void flock_activate();
	LVecBase3f do_flock();

  int char_to_int(string ai_type);

PUBLISHED:
	void seek(NodePath target_object, float seek_wt = 1.0);
	void seek(LVecBase3f pos, float seek_wt = 1.0);
	bool seek_status();

	void flee(NodePath target_object, double panic_distance = 10.0, double relax_distance = 10.0, float flee_wt = 1.0);
	void flee(LVecBase3f pos, double panic_distance = 10.0, double relax_distance = 10.0, float flee_wt = 1.0);
	bool flee_status();

	void pursue(NodePath target_object, float pursue_wt = 1.0);
	bool pursue_status();

	void evade(NodePath target_object, double panic_distance = 10.0, double relax_distance = 10.0, float evade_wt = 1.0);
	bool evade_status();

	void arrival(NodePath target_object, double distance = 10.0);
	bool arrival_status();

	void flock(float flock_wt);
	bool flock_status();

	void wander(double wander_radius = 5.0, bool flag_3D = false, double aoe = 0.0, float wander_weight = 1.0);
	bool wander_status();

	void remove_ai(string ai_type);
  void pause_ai(string ai_type);
  void resume_ai(string ai_type);
};

#endif











