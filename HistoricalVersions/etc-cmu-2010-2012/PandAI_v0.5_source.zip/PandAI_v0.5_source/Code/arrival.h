////////////////////////////////////////////////////////////////////////
//! Filename		: arrival.h
//! Created by	: Deepak, John, Navin
//! Date				:	24 Oct 09
////////////////////////////////////////////////////////////////////////
//!
//! PANDA3D SOFTWARE
//! Copyright(c) Carnegie Mellon University. All rights reserved.
//!
//!	All use of this software is subjest to the terms of the revised BSD
//!	license. You should have received a copy of this license along with this source code in a file named "LICENSE"

////////////////////////////////////////////////////////////////////////

#ifndef _ARRIVAL_H
#define _ARRIVAL_H

#include "globals.h"
#include "aiCharacter.h"

class AICharacter;

class Arrival {

public:
	AICharacter *_ai_char;

	NodePath _arrival_target;
	double _arrival_distance;
	LVecBase3f _arrival_direction;
	bool _arrival_done;

	Arrival(AICharacter *ai_ch, NodePath target_object, double distance = 10.0);
	~Arrival();
	LVecBase3f do_arrival();
	void arrival_activate();
};

#endif
