////////////////////////////////////////////////////////////////////////
//! Filename		: aiBehaviors.cxx
//! Created by	: Deepak, John, Navin
//! Date				:	8 Sep 09
////////////////////////////////////////////////////////////////////////
//!
//! PANDA3D SOFTWARE
//! Copyright(c) Carnegie Mellon University. All rights reserved.
//!
//!	All use of this software is subjest to the terms of the revised BSD
//!	license. You should have received a copy of this license along with this source code in a file named "LICENSE"

////////////////////////////////////////////////////////////////////////

#include "aiBehaviors.h"

static const float _PI = 3.14;

AIBehaviors::AIBehaviors() {
	_steering_force = LVecBase3f(0.0, 0.0, 0.0);
	_behaviors_flags = _behaviors_flags & _none;
	_previous_conflict = false;
	_conflict = false;

	_seek_obj = NULL;
	_flee_obj = NULL;
	_pursue_obj = NULL;
	_evade_obj = NULL;
	_arrival_obj = NULL;
	_wander_obj = NULL;
	_flock_group = NULL;

	seek_off();
	flee_off();
	pursue_off();
	evade_off();
	arrival_off();
	flock_off();
	wander_off();

}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : is_conflict
//! Description : Checks for conflict between steering forces.
//!								If there is a conflict it returns 'true' and sets _conflict to 'true'.
//!								If there is no conflict it returns 'false' and sets _conflict to 'false'.

/////////////////////////////////////////////////////////////////////////////////

bool AIBehaviors::is_conflict() {
	int value = int(On(_seek)) + int(On(_flee)) + int(On(_pursue)) + int(On(_evade)) + int(On(_wander)) + int(On(_flock));

	if(value > 1) {
		if(_previous_conflict == false) {
			if(On(_seek)) {
				_seek_force *= _seek_obj->_seek_weight;
			}

			if(On(_flee)) {
				LVecBase3f dirn = _flee_force;
				dirn.normalize();
				_flee_force = _steering_force.length() * dirn * _flee_obj->_flee_weight;
			}

			if(On(_pursue)) {
				_pursue_force *= _pursue_obj->_pursue_weight;
			}

			if(On(_evade)) {
				LVecBase3f dirn = _evade_force;
				dirn.normalize();
				_evade_force = _steering_force.length() * dirn * _evade_obj->_evade_weight;
			}

			if(On(_flock)) {
				_flock_force *= _flock_weight;
			}

			if(On(_wander)) {
				_wander_force *= _wander_obj->_wander_weight;
			}

			_previous_conflict = true;
		}

		_conflict = true;
		return true;
	}

	_conflict = false;
	_previous_conflict = false;
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//!
//! Function : accumulate_force
//! Description : This function updates the individual steering forces for each of the ai characters.
//!								These accumulated forces are eventually what comprise the resultant
//!								steering force of the character.

/////////////////////////////////////////////////////////////////////////////////////////////////////


void AIBehaviors::accumulate_force(string force_type, LVecBase3f force) {

	LVecBase3f old_force;

	if(force_type == "seek") {
		old_force = _seek_force;
		_seek_force = old_force + force;
	}

	if(force_type == "flee") {
		old_force = _flee_force;
		_flee_force = old_force + force;
	}

	if(force_type == "pursue") {
		old_force = _pursue_force;
		double new_force = old_force.length() + force.length();
		_pursue_force = new_force * _pursue_obj->_pursue_direction;
	}

	if(force_type == "evade") {
		old_force = _evade_force;
		double new_force = old_force.length() + force.length();
		force.normalize();
		_evade_force = new_force * force;
	}

	if(force_type == "arrival") {
		_arrival_force = force;
	}

	if(force_type == "flock") {
		old_force = _flock_force;
		_flock_force = old_force + force;
	}

	if(force_type == "wander") {
		old_force = _wander_force;
		_wander_force = old_force + force;
	}

}

//////////////////////////////////////////////////////////////////////////////////////////////
//!
//! Function : calculate_prioritized
//! Description : This function updates the main steering force for the ai character using
//!								the accumulate function and checks for max force and arrival force.
//!								It finally returns this steering force which is accessed by the update
//!								function in the AICharacter class.

//////////////////////////////////////////////////////////////////////////////////////////////

LVecBase3f AIBehaviors::calculate_prioritized() {
	LVecBase3f force;

	if(is_seek_on()) {
		if(_conflict) {
			force = _seek_obj->do_seek() * _seek_obj->_seek_weight;
		}
		else {
			force = _seek_obj->do_seek();
		}

		accumulate_force("seek",force);
	}

	if(is_flee_activate_on()) {
		for(_flee_itr = _flee_list.begin(); _flee_itr != _flee_list.end(); _flee_itr++) {
			_flee_itr->flee_activate();
		}
	}

	if(is_flee_on()) {
		for(_flee_itr = _flee_list.begin(); _flee_itr != _flee_list.end(); _flee_itr++) {
			if(_flee_itr->_flee_activate_done) {
				if(_conflict) {
					force = _flee_itr->do_flee() * _flee_itr->_flee_weight;
				}
				else {
					force = _flee_itr->do_flee();
				}
				accumulate_force("flee",force);
			}
		}
	}

	if(is_pursue_on()) {
		if(_conflict) {
			force = _pursue_obj->do_pursue() * _pursue_obj->_pursue_weight;
		}
		else {
			force = _pursue_obj->do_pursue();
		}
		accumulate_force("pursue",force);
	}

	if(is_evade_activate_on()) {
		for(_evade_itr = _evade_list.begin(); _evade_itr != _evade_list.end(); _evade_itr++) {
			_evade_itr->evade_activate();
		}
	}

	if(is_evade_on()) {
		for(_evade_itr = _evade_list.begin(); _evade_itr != _evade_list.end(); _evade_itr++) {
			if(_evade_itr->_evade_activate_done) {
				if(_conflict) {
					force = (_evade_itr->do_evade()) * (_evade_itr->_evade_weight);
				}
				else {
					force = _evade_itr->do_evade();
				}
				accumulate_force("evade",force);
			}
		}
	}

	if(is_arrival_activate_on()) {
			_arrival_obj->arrival_activate();
	}

	if(is_arrival_on()) {
		force = _arrival_obj->do_arrival();
		accumulate_force("arrival",force);
	}

  if(is_flock_activate_on()) {
			flock_activate();
	}

	if(is_flock_on()) {
		if(_conflict) {
			force = do_flock() * _flock_weight;
		}
		else {
			force = do_flock();
		}
		accumulate_force("flock",force);
	}

	if(is_wander_on()) {
		if(_conflict) {
			force = _wander_obj->do_wander() * _wander_obj->_wander_weight;
		}
		else {
			force = _wander_obj->do_wander();
		}
		accumulate_force("wander", force);
	}

	is_conflict();

	_steering_force += _seek_force * int(On(_seek)) + _flee_force * int(On(_flee)) +
											_pursue_force * int(On(_pursue)) + _evade_force * int(On(_evade)) +
											_flock_force * int(On(_flock)) + _wander_force * int(On(_wander));

	if(_steering_force.length() > _ai_char->get_max_force()) {
		_steering_force.normalize();
		_steering_force = _steering_force * _ai_char->get_max_force();
	}

	if(On(_arrival)) {
		if(_seek_obj != NULL) {
			LVecBase3f dirn = _steering_force;
			dirn.normalize();
			_steering_force = ((_steering_force.length() - _arrival_force.length()) * dirn);
		}

		if(_pursue_obj != NULL) {
			LVecBase3f dirn = _steering_force;
			dirn.normalize();
			_steering_force = ((_steering_force.length() - _arrival_force.length()) * _arrival_obj->_arrival_direction);
		}
	}

	return _steering_force;
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : remove_ai
//! Description : This function removes individual or all the AIs.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::remove_ai(string ai_type) {
  switch(char_to_int(ai_type)) {
		case 0: {
							remove_ai("seek");
							remove_ai("flee");
							remove_ai("pursue");
							remove_ai("evade");
							remove_ai("arrival");
							remove_ai("flock");
              remove_ai("wander");
							break;
						}

		case 1:	{
							if(_seek_obj != NULL) {
                seek_off();
								delete _seek_obj;
								_seek_obj = NULL;
							}
							break;
						}

		case 2: {
							while (!_flee_list.empty()) {
                flee_off();
							  flee_activate_off();
								_flee_list.pop_front();
							}
							break;
						}

		case 3: {
							if(_pursue_obj != NULL) {
                pursue_off();
								delete _pursue_obj;
								_pursue_obj = NULL;
							}
							break;
						}

		case 4: {
							while (!_evade_list.empty()) {
                evade_off();
							  evade_activate_off();
								_evade_list.pop_front();
							}
							break;
						}

		case 5: {
							if(_arrival_obj != NULL) {
                arrival_off();
							  arrival_activate_off();
								delete _arrival_obj;
								_arrival_obj = NULL;
							}
							break;
						}

		case 6: {
              if(_flock_group != NULL) {
							  flock_off();
							  flock_activate_off();
							  _flock_group = NULL;
              }
							break;
						}

		case 7: {
							if(_wander_obj != NULL) {
                wander_off();
								delete _wander_obj;
								_wander_obj = NULL;
							}
							break;
						}
		default:
		        cout<<"Invaled option!"<<endl;
	}
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : pause_ai
//! Description : This function pauses individual or all the AIs.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::pause_ai(string ai_type) {
	switch(char_to_int(ai_type)) {
		case 0: {
							pause_ai("seek");
							pause_ai("flee");
							pause_ai("pursue");
							pause_ai("evade");
							pause_ai("arrival");
							pause_ai("flock");
              pause_ai("wander");
							break;
						}

		case 1:	{
							if(_seek_obj != NULL) {
                seek_off();
							}
							break;
						}

		case 2: {
              for(_flee_itr = _flee_list.begin(); _flee_itr != _flee_list.end(); _flee_itr++) {
                flee_off();
				        flee_activate_off();
              }
							break;
						}

		case 3: {
							if(_pursue_obj != NULL) {
                pursue_off();
							}
							break;
						}

		case 4: {
              for(_evade_itr = _evade_list.begin(); _evade_itr != _evade_list.end(); _evade_itr++) {
                evade_off();
							  evade_activate_off();
              }
							break;
						}

		case 5: {
							if(_arrival_obj != NULL) {
                arrival_off();
							  arrival_activate_off();
							}
							break;
						}

		case 6: {
              if(_flock_group != NULL) {
							  flock_off();
							  flock_activate_off();
              }
							break;
						}

		case 7: {
							if(_wander_obj != NULL) {
                wander_off();
							}
							break;
						}
		default:
		        cout<<"Invaled option!"<<endl;
	}
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : resume_ai
//! Description : This function resumes individual or all the AIs

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::resume_ai(string ai_type) {
	switch(char_to_int(ai_type)) {
		case 0: {
							resume_ai("seek");
							resume_ai("flee");
							resume_ai("pursue");
							resume_ai("evade");
							resume_ai("arrival");
							resume_ai("flock");
              resume_ai("wander");
							break;
						}

		case 1:	{
							if(_seek_obj != NULL) {
                seek_on();
							}
							break;
						}

		case 2: {
							for(_flee_itr = _flee_list.begin(); _flee_itr != _flee_list.end(); _flee_itr++) {
                flee_on();
							}
							break;
						}

		case 3: {
							if(_pursue_obj != NULL) {
                pursue_on();
							}
							break;
						}

		case 4: {
							for(_evade_itr = _evade_list.begin(); _evade_itr != _evade_list.end(); _evade_itr++) {
                evade_on();
							}
							break;
						}

		case 5: {
							if(_arrival_obj != NULL) {
                arrival_on();
							}
							break;
						}

		case 6: {
              if(_flock_group != NULL) {
							  flock_on();
              }
							break;
						}

		case 7: {
							if(_wander_obj != NULL) {
                wander_on();
							}
							break;
						}
		default:
		        cout<<"Invaled option!"<<endl;
	}
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : seek
//! Description : This function activates seek and makes an object of the Seek class.
//!								This is the function we want the user to call for seek to be done.
//!								This function is overloaded to accept a NodePath or an LVecBase3f.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::seek(NodePath target_object, float seek_wt) {
	_seek_obj = new Seek(_ai_char, target_object, seek_wt);
	seek_on();
}

void AIBehaviors::seek(LVecBase3f pos, float seek_wt) {
	_seek_obj = new Seek(_ai_char, pos, seek_wt);
	seek_on();
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : seek_status
//! Description : This function returns the current status of seek.

/////////////////////////////////////////////////////////////////////////////////

bool AIBehaviors::seek_status() {
	return(_seek_obj->_seek_done);
}

//////////////////////////////////////////////////////////////////////////////////////////////////
//!
//! Function : flee
//! Description : This function activates flee_activate and creates an object of the Flee class.
//!								This function is overloaded to accept a NodePath or an LVecBase3f.

//////////////////////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::flee(NodePath target_object, double panic_distance, double relax_distance, float flee_wt) {
	_flee_obj = new Flee(_ai_char, target_object, panic_distance, relax_distance, flee_wt);
	_flee_list.insert(_flee_list.end(), *_flee_obj);

	flee_activate_on();
}

void AIBehaviors::flee(LVecBase3f pos, double panic_distance, double relax_distance, float flee_wt) {
	_flee_obj = new Flee(_ai_char, pos, panic_distance, relax_distance, flee_wt);
	_flee_list.insert(_flee_list.end(), *_flee_obj);

	flee_activate_on();
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : flee_status
//! Description : This function returns the current status of flee.

/////////////////////////////////////////////////////////////////////////////////

bool AIBehaviors::flee_status() {
  unsigned int i = 0;
  for(_flee_itr = _flee_list.begin(); _flee_itr != _flee_list.end(); _flee_itr++) {
    if(_flee_itr->_flee_done == true) {
      ++i;
    }
  }
  if(i == _flee_list.size()) {
    return true;
  }
  else {
    return false;
  }
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : pursue
//! Description : This function activates pursue.
//!								This is the function we want the user to call for pursue to be done.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::pursue(NodePath target_object, float pursue_wt) {
	_pursue_obj = new Pursue(_ai_char, target_object, pursue_wt);

	pursue_on();
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : pursue_status
//! Description : This function returns the current status of pursue.

/////////////////////////////////////////////////////////////////////////////////

bool AIBehaviors::pursue_status() {
	return(_pursue_obj->_pursue_done);
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : evade
//! Description : This function activates evade_activate.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::evade(NodePath target_object, double panic_distance, double relax_distance, float evade_wt) {
	_evade_obj = new Evade(_ai_char, target_object, panic_distance, relax_distance, evade_wt);
	_evade_list.insert(_evade_list.end(), *_evade_obj);

	evade_activate_on();
}


/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : evade_status
//! Description : This function returns the current status of evade.

/////////////////////////////////////////////////////////////////////////////////

bool AIBehaviors::evade_status() {
  unsigned int i = 0;
  for(_evade_itr = _evade_list.begin(); _evade_itr != _evade_list.end(); _evade_itr++) {
    if(_evade_itr->_evade_done == true) {
      ++i;
    }
  }
  if(i == _evade_list.size()) {
    return true;
  }
  else {
    return false;
  }
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : arrival
//! Description : This function activates arrival.
//!								This is the function we want the user to call for arrival to be done.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::arrival(NodePath target_object, double distance) {
	_arrival_obj = new Arrival(_ai_char, target_object, distance);

	arrival_activate_on();
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : arrival_status
//! Description : This function returns the current status of arrival.

/////////////////////////////////////////////////////////////////////////////////

bool AIBehaviors::arrival_status() {
	return(_arrival_obj->_arrival_done);
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : flock
//! Description : This function activates flock.
//!								This is the function we want the user to call for flock to be done.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::flock(float flock_wt) {
	_flock_weight = flock_wt;

  _flock_done = false;
  flock_activate_on();
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : flock_status
//! Description : This function returns the current status of flock.

/////////////////////////////////////////////////////////////////////////////////

bool AIBehaviors::flock_status() {
	return(_flock_done);
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : flock_activate
//! Description : This function checks whether any other behavior exists to work with flock.
//!								When this is true, it calls the do_flock function.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::flock_activate() {
	if(On(_seek) || On(_flee) || On(_pursue) || On(_evade) || On(_wander)) {
			flock_activate_off();
			flock_on();
	}
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : do_flock
//! Description : This function contains the logic for flocking behavior. This is
//!								an emergent behavior and is obtained by combining three other
//!								behaviors which are separation, cohesion and alignment based on
//!								Craig Reynold's algorithm. Also, this behavior does not work by
//!								itself. It works only when combined with other steering behaviors
//!								such as wander, pursue, evade, seek and flee.

/////////////////////////////////////////////////////////////////////////////////

LVecBase3f AIBehaviors::do_flock() {

  //! Initialize variables required to compute the flocking force on the ai char.
  unsigned int neighbor_count = 0;
  LVecBase3f separation_force = LVecBase3f(0.0, 0.0, 0.0);
  LVecBase3f alignment_force = LVecBase3f(0.0, 0.0, 0.0);
  LVecBase3f cohesion_force = LVecBase3f(0.0, 0.0, 0.0);
  LVecBase3f avg_neighbor_heading = LVecBase3f(0.0, 0.0, 0.0);
  LVecBase3f total_neighbor_heading = LVecBase3f(0.0, 0.0, 0.0);
  LVecBase3f avg_center_of_mass = LVecBase3f(0.0, 0.0, 0.0);
  LVecBase3f total_center_of_mass = LVecBase3f(0.0, 0.0, 0.0);

	//! Loop through all the other AI units in the flock to check if they are neigbours.
	for(unsigned int i = 0; i < _flock_group->_ai_char_list.size(); i++) {
		if(_flock_group->_ai_char_list[i]->_name != _ai_char->_name) {

			//! Using visibilty cone to detect neighbors.
			LVecBase3f dist_vect = _flock_group->_ai_char_list[i]->_ai_char_np.get_pos() - _ai_char->_ai_char_np.get_pos();
			LVecBase3f ai_char_heading = _ai_char->get_velocity();
      ai_char_heading.normalize();

			//! Check if the current unit is a neighbor.
      if(dist_vect.dot(ai_char_heading) > ((dist_vect.length()) * (ai_char_heading.length()) * cos(_flock_group->_flock_vcone_angle * (_PI / 180)))
        && (dist_vect.length() < _flock_group->_flock_vcone_radius)) {
          //! Separation force calculation.
          LVecBase3f ai_char_to_units = _ai_char->_ai_char_np.get_pos() - _flock_group->_ai_char_list[i]->_ai_char_np.get_pos();
          float to_units_dist = ai_char_to_units.length();
          ai_char_to_units.normalize();
          separation_force += (ai_char_to_units / to_units_dist);

          //! Calculating the total heading and center of mass of all the neighbors.
          LVecBase3f neighbor_heading = _flock_group->_ai_char_list[i]->get_velocity();
          neighbor_heading.normalize();
          total_neighbor_heading += neighbor_heading;
          total_center_of_mass += _flock_group->_ai_char_list[i]->_ai_char_np.get_pos();

					//! Update the neighbor count.
          ++neighbor_count;
			}
		}
  }

  if(neighbor_count > 0) {
    //! Alignment force calculation
    avg_neighbor_heading = total_neighbor_heading / neighbor_count;
    LVector3f ai_char_heading = _ai_char->get_velocity();
    ai_char_heading.normalize();
    avg_neighbor_heading -= ai_char_heading;
    avg_neighbor_heading.normalize();
    alignment_force = avg_neighbor_heading;

    //! Cohesion force calculation
    avg_center_of_mass = total_center_of_mass / neighbor_count;
    LVecBase3f cohesion_dir = avg_center_of_mass - _ai_char->_ai_char_np.get_pos();
    cohesion_dir.normalize();
    cohesion_force = cohesion_dir * _ai_char->_movt_force;
  }
  else if(On(_seek) || On(_flee) || On(_pursue) || On(_evade) || On(_wander)) {
		_flock_done = true;
		flock_off();
		flock_activate_on();
		return(LVecBase3f(0.0, 0.0, 0.0));
  }

	//! Calculate the resultant force on the ai character by taking into account the separation, alignment and cohesion
	//! forces along with their corresponding weights.
  return (separation_force * _flock_group->_separation_wt + avg_neighbor_heading * _flock_group->_alignment_wt
    + cohesion_force * _flock_group->_cohesion_wt);
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : wander
//! Description : This function activates wander.
//!               This is the function we want the user to call for flock to be done.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::wander(double wander_radius, bool flag_3D, double aoe, float wander_weight) {
  _wander_obj = new Wander(_ai_char, wander_radius, flag_3D, aoe, wander_weight);
  wander_on();
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : wander_status
//! Description : This function returns the current status of wander.

/////////////////////////////////////////////////////////////////////////////////

bool AIBehaviors::wander_status() {
  if(On(_wander)) {
    return false;
  }
  else {
    return true;
  }
}

/////////////////////////////////////////////////////////////////////////////////
//!
//! Function : (aitype)_off()
//! Description : These functions are used to turn off the steering forces.

/////////////////////////////////////////////////////////////////////////////////

void AIBehaviors::seek_off() {
	if (On(_seek)) {
		_behaviors_flags ^= _seek;
	}
	_seek_force = LVecBase3f(0.0f, 0.0f, 0.0f);
}

void AIBehaviors::flee_off() {
	if (On(_flee)) {
		_behaviors_flags ^= _flee;
	}
	_flee_force = LVecBase3f(0.0f, 0.0f, 0.0f);
}

void AIBehaviors::pursue_off() {
	if(On(_pursue)) {
		_behaviors_flags ^= _pursue;
	}
	_pursue_force = LVecBase3f(0.0f, 0.0f, 0.0f);
}

void AIBehaviors::evade_off() {
	if(On(_evade)) {
		_behaviors_flags ^= _evade;
	}
	_evade_force = LVecBase3f(0.0f, 0.0f, 0.0f);
}

void AIBehaviors::arrival_off() {
	if (On(_arrival)) {
		_behaviors_flags ^= _arrival;
	}
	_arrival_force = LVecBase3f(0.0f, 0.0f, 0.0f);
}

void AIBehaviors::flock_off() {
	if(On(_flock)) {
		_behaviors_flags ^= _flock;
	}
	_flock_force = LVecBase3f(0.0f, 0.0f, 0.0f);
}

void AIBehaviors::wander_off() {
	if(On(_wander)) {
		_behaviors_flags ^= _wander;
	}
	_wander_force = LVecBase3f(0.0, 0.0, 0.0);
}

///////////////////////////////////////////////////////////////////////////////////////
//!
//! Function : char_to_int
//! Description : This function is used to derive int values from the ai types strings.
//!								Returns -1 if an invalid string is passed.

///////////////////////////////////////////////////////////////////////////////////////

int AIBehaviors::char_to_int(string ai_type) {
  if(ai_type == "all") {
    return 0;
  }
  else if(ai_type == "seek") {
    return 1;
  }
  else if(ai_type == "flee") {
    return 2;
  }
  else if(ai_type == "pursue") {
    return 3;
  }
  else if(ai_type == "evade") {
    return 4;
  }
  else if(ai_type == "arrival") {
    return 5;
  }
  else if(ai_type == "flock") {
    return 6;
  }
  else if(ai_type == "wander") {
    return 7;
  }
  return -1;
}
