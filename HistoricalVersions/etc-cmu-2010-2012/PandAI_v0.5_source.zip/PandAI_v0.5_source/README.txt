
To read the documentation, open the index.html in the Documentation folder first.