
#2DO: Fix restart later

#***********************HEADERS**********************************************
#for directx window and functions
import direct.directbase.DirectStart
from pandac.PandaModules import *

from pandac.PandaModules import Filename,Buffer,Shader
#for directx object support
from direct.showbase.DirectObject import DirectObject
#for intervals
from direct.interval.IntervalGlobal import *
#for FSM
from direct.fsm import FSM
from direct.fsm import State
#for tasks
from direct.task import Task
#for Actors
from direct.actor.Actor import Actor
#for math
import math
import random
#for system commands
import sys
#for directGUI
from direct.gui.DirectGui import *
from direct.gui.OnscreenText import OnscreenText

#My class to reference Pandai ... this does the import libpandai too
from MyCharacter import *

from pandac.PandaModules import WindowProperties

#************************GLOBAL**********************************************

speed = 1.0
BUBBLE_NOS = 50
Fish_Nos = 30

#**********************BASE CLASS (FSM)**************************************

class GameWorld(DirectObject,FSM.FSM):
    def __init__(self, name):
        FSM.FSM.__init__(self, name)
        self.defaultTransitions={'Off':['Intro',],'Intro':['Game',], 'Game':['EndGame',]}
       
        base.cam.setPosHpr(0,-180,50,0,355,0)
        self.cam_old = base.cam.getPos()
        self.fishnos = Fish_Nos
        
        #Extra Variables
        self.light_state = 1 # to start with red light
            
        #Loading screen
        loadingscreen = CardMaker("StartScreen")
        loadingscreen.setFrame(-1,1,-1,1)
        
        text = CardMaker("words")
        text.setFrame(-0.5,0.5,-0.5,0.5)
              
        title_screen = loader.loadTexture("Texture/intro/fishdemo.png")
        p = loader.loadTexture("Texture/intro/P.png")
        a1 = loader.loadTexture("Texture/intro/A1.png")
        n = loader.loadTexture("Texture/intro/N.png")
        d = loader.loadTexture("Texture/intro/D.png")
        a2 = loader.loadTexture("Texture/intro/A2.png")
        i = loader.loadTexture("Texture/intro/I.png")
        
        self.startnode = NodePath(loadingscreen.generate())
        self.startnode.setTexture(title_screen)
        self.startnode.setTransparency(TransparencyAttrib.MAlpha)
        
        self.logo_p = NodePath(text.generate())
        self.logo_p.setTexture(p)
        self.logo_p.setTransparency(TransparencyAttrib.MAlpha)
        
        self.logo_a1 = NodePath(text.generate())
        self.logo_a1.setTexture(a1)
        self.logo_a1.setTransparency(TransparencyAttrib.MAlpha)
        
        self.logo_n = NodePath(text.generate())
        self.logo_n.setTexture(n)
        self.logo_n.setTransparency(TransparencyAttrib.MAlpha)
        
        self.logo_d = NodePath(text.generate())
        self.logo_d.setTexture(d)
        self.logo_d.setTransparency(TransparencyAttrib.MAlpha)
        
        self.logo_a2 = NodePath(text.generate())
        self.logo_a2.setTexture(a2)
        self.logo_a2.setTransparency(TransparencyAttrib.MAlpha)
        
        self.logo_i = NodePath(text.generate())
        self.logo_i.setTexture(i)
        self.logo_i.setTransparency(TransparencyAttrib.MAlpha)        
   
        #Creating AI World
        self.AIWorld = AIWorld(render)
        
        self.dummy_node = NodePath(" ")
        self.cam_move = False
        self.Mode = True
        self.Active = True
        self.caught_fish = None
        
        #Start the world
        self.request("Intro")
        
    #*************FSM**************************************************
      
    def enterIntro(self):
        self.init()
        self.accept("space", self.goToStart) # starts the game
        
        self.startnode.reparentTo(render2d)
        self.logo_p.reparentTo(render2d)
        self.logo_a1.reparentTo(render2d)
        self.logo_n.reparentTo(render2d)
        self.logo_d.reparentTo(render2d)
        self.logo_a2.reparentTo(render2d)
        self.logo_i.reparentTo(render2d)
        
        self.Fish_intro = Character(self, "-1", 100.0, 0.1, 30.0)
        self.Fish_intro.place(Vec3(0,-20,50))
        
        #AI World update  
        taskMgr.add(self.AIUpdate,"AIUpdate")
        
    def exitIntro(self):
        pass
    
    def goToStart(self):
        LerpPosInterval(self.logo_p, 5, self.logo_p.getPos() + Vec3(-5,0,5), self.logo_p.getPos()).start()
        LerpPosInterval(self.logo_a1, 5, self.logo_a1.getPos() + Vec3(-5,0,0), self.logo_a1.getPos()).start()
        LerpPosInterval(self.logo_n, 5, self.logo_n.getPos() + Vec3(-2,0,3), self.logo_n.getPos()).start()
        LerpPosInterval(self.logo_d, 5, self.logo_d.getPos() + Vec3(3,0,-2), self.logo_d.getPos()).start()
        LerpPosInterval(self.logo_a2, 5, self.logo_a2.getPos() + Vec3(5,0,0), self.logo_a2.getPos()).start()
        LerpPosInterval(self.logo_i, 5, self.logo_i.getPos() + Vec3(5,0,-5), self.logo_i.getPos()).start()        
        
        taskMgr.doMethodLater(1, self.delayStart, "delayStart")
        
    def delayStart(self, task):
        self.request("Game")
       
    def enterGame(self):
        self.startnode.hide()
        self.Fish_intro.Model.reparentTo(self.dummy_node)
        
        self.accept("escape",self.endGame)
        
        base.disableMouse()
        
        self.startGame()
                
    def exitGame(self):
        pass
       
    def enterEndGame(self):
        sys.exit()
        
    def exitEndGame(self):
        pass
        
        
    #*************FUNCTIONS**************************************************
        
    def find_mouse_pos(self, task):
        if base.mouseWatcherNode.hasMouse(): 
            mpos = base.mouseWatcherNode.getMouse() 

            nearPoint = Point3()
            farPoint = Point3()
            pos3d = Point3()
            
            base.camLens.extrude(mpos, nearPoint, farPoint)         
            if self.plane.intersectsLine(pos3d, 
              render.getRelativePoint(camera, nearPoint), 
              render.getRelativePoint(camera, farPoint)): 
                self.mouse_x = pos3d.getX()
                self.mouse_z = pos3d.getZ() + 30
            
        return task.cont
        
    def setCollisions(self):        
        for i in range(self.fishnos):
            self.collTrav.addCollider(self.Fish[i].collcnp,self.collhp)
            self.collhp.addCollider(self.Fish[i].collcnp,self.Fish[i].Model)    
                  
    def removeCollisions(self):
        for i in range(self.fishnos):
            self.collTrav.removeCollider(self.Fish[i].collcnp)
            self.collhp.removeCollider(self.Fish[i].collcnp) 
                  
    def drawLines(self, task):
        self.parent.removeAllChildren()          
        self.lines.reset()
        self.lines.moveTo(self.Hook_top.getPos(render))
        self.lines.drawTo(self.startHookPos)
        self.parent.addChild(self.lines.create())
        return task.cont

    def start_hook(self):
        if(self.Active):
            self.Mode = not self.Mode
            
            if(self.Mode == False):
                for i in range(self.fishnos):
                    self.Fish[i].evade_start = False
                    self.Fish[i].remove("evade")
                    self.Fish[i].remove("all")
        
                self.wander()
                self.pursuit()
                taskMgr.doMethodLater(1, self.start_checker, "start_checker")

                #to hide mouse pointer
                props = WindowProperties()
                props.setCursorHidden(True) 
                base.win.requestProperties(props)
                
                self.setCollisions()
                self.startHookPos = Vec3(self.mouse_x,0,100)

                LerpPosInterval(self.Hook, 0.5, Vec3(self.mouse_x,-20,self.mouse_z), Vec3(self.mouse_x, self.Hook.getY(), self.Hook.getZ())).start()
                taskMgr.add(self.mouse_track, "mouse_track")
            else:
                for i in range(self.fishnos):
                    self.Fish[i].remove("pursue")
                taskMgr.remove("start_checker")
                taskMgr.remove("mouse_track")
                taskMgr.add(self.zoom_out, "zoom out")
                taskMgr.add(self.remove_hook, "remove_hook")
        
    def mouse_track(self, task):
        if base.mouseWatcherNode.hasMouse():
            self.Hook.setX(self.mouse_x)
            self.Hook.setR(self.mouse_x)
            self.Hook.setZ(self.mouse_z)
        
        return task.cont
    
    def start_checker(self, task):

        for i in range(self.fishnos):
            if(self.Fish[i].pursue_start):
                self.removeCollisions()
                
            if(self.Fish[i].status("pursue")):
                self.pause_all_fishes()
                self.caught_fish = self.Fish[i]
                self.Worm.reparentTo(self.dummy_node)
                self.Fish[i].Model.reparentTo(self.Hook)
                self.Fish[i].Model.setPos(6.10,0,-2.90)
                self.Fish[i].Model.setScale(1.1)
                self.Fish[i].Model.loop("struggle")
                self.Fish[i].Model.setPlayRate(2.0, "struggle")
                self.Fish[i].Model.setHpr(270,329.74,0)
                self.pan_camera("zoomin")
                taskMgr.doMethodLater(4, self.fleeAway, "fleeAway")
                taskMgr.remove("start_checker")
                self.Active = False
                break
            
        return task.cont
    
    def fleeAway(self, task):
        self.cam_move = True
        self.resume_all_fishes()
        self.stop_prox_check()
        self.Active = True
    
    def zoom_out(self, task):
        self.pan_camera("zoomout")
        
    def remove_hook(self, task):
        self.cam_move = True
        LerpPosInterval(self.Hook, 3, self.Hook.getPos() + Vec3(0,0,100), self.Hook.getPos()).start()
        self.Active = False
        taskMgr.doMethodLater(3, self.removeFish, "removeFish")
            
    def removeFish(self, task):
        if(self.caught_fish != None):
            self.hidenode = NodePath("blah")
            self.caught_fish.Model.reparentTo(self.hidenode)
            self.caught_fish.Model.setPos(300,300,300)
            self.caught_fish = None
        self.Worm.reparentTo(self.Hook)
        self.Active = True

        props = WindowProperties()
        props.setCursorHidden(False) 
        base.win.requestProperties(props)
    
    def pan_camera(self, type):
        if(type=="zoomin"):
            LerpPosInterval(base.cam, 2, self.Hook.getPos() + Vec3(0,-90,5), base.cam.getPos()).start()
            #taskMgr.doMethodLater(3,self.stopLight_start, "stopLight")
        if(type=="zoomout"):
            LerpPosInterval(base.cam, 2, self.cam_old, base.cam.getPos()).start()
            #taskMgr.doMethodLater(1,self.resetLight_start, "resetLight")
    
    def stopLight_start(self, task):
        self.stopLight()

    def resetLight_start(self, task):
        self.resetLight()

    def pause_all_fishes(self):
        for i in range(self.fishnos):
            self.Fish[i].pause()

    def resume_all_fishes(self):
        for i in range(self.fishnos):
            if(self.Fish[i] == self.caught_fish):
                pass
            else:
                self.Fish[i].resume()
                self.Fish[i].evade(self.Hook, 30, 10, 0.5)

    def pursuit(self):
        for i in range(self.fishnos):
            self.Fish[i].proximityCheck(self.Worm, 50)
    
    def stop_prox_check(self):
        for i in range(self.fishnos):
            self.Fish[i].stop_proximityCheck()

    def wander(self):
        for i in range(self.fishnos):
            self.Fish[i].wander(4, 3, 100, 0.5)
        
    def startGame(self):
        self.accept("mouse1", self.start_hook)
        
        #creating the AICharacters
        self.Fish = []
        for i in range(self.fishnos):
            self.Fish.append(Character(self, str(i), 100.0, 0.1, 30.0))
            self.Fish[i].place(Vec3(0,-20,50))
 
        self.lines = LineSegs("hook_line")
        self.lines.setThickness(2);
        self.lines.setColor(1,1,1,1)
        self.parent = GeomNode("drawer")
        render.attachNewNode(self.parent)

        self.mouse = base.mouseWatcherNode;
        self.plane = Plane(Vec3(0, 1, 0), Point3(0, 150, 0)) 
        self.mouse_x_interval = 0
                  
        self.startHookPos = Vec3(-10,0,100)
                  
        taskMgr.add(self.drawLines,"drawline")
        
        taskMgr.add(self.find_mouse_pos, "find mouse pos")
        
        #To Handle collisions
        #Collision Traverser
        self.collTrav = CollisionTraverser()
        base.cTrav = self.collTrav
        
        #Pusher used to handle geometry issues upon collision
        self.collhp = CollisionHandlerPusher()
        
        self.wander()
        
        taskMgr.doMethodLater(5, self.startCollisions, "startCollisions")
        
    def startCollisions(self, task):
        self.setCollisions()
                
    #to initialize models, lights
    def init(self):
        print("Hello World - init")
        
        self.Enviro = loader.loadModel("EggFile/ocean");
        self.Enviro.setScale(2)
        self.Enviro.setPosHpr(-30,0,-30,0,40,0)
        self.Enviro.reparentTo(render)
        
        self.bubbles = []
        
        for i in range(BUBBLE_NOS):
            self.bubbles.append(loader.loadModel("EggFile/bubbles"))
            self.bubbles[i].reparentTo(render)
            self.bubbles[i].setScale(0.02 * (random.random() * 2))
            self.bubbles[i].setPos(-100 + i * 5,0,-50)
            LerpPosInterval(self.bubbles[i], 10 * random.random(), self.bubbles[i].getPos() + Vec3(0,0,200), self.bubbles[i].getPos()).start()
          
        self.Hook = Actor("EggFile/hook");
        self.Hook.setScale(0.5)
        self.Hook.setPos(-40,-20,100)
        self.Hook.reparentTo(render)
        
        self.Hook_top = self.Hook.exposeJoint(None,"modelRoot","hook_top")

        self.Worm = Actor("EggFile/worm", {"wiggle":"EggFile/worm_anim"})
        self.Worm.setScale(1)
        self.Worm.setPos(5,0,6)
        self.Worm.reparentTo(self.Hook)
        self.Worm.loop("wiggle")
        
        #lights
        self.dirnlight = DirectionalLight("dirn_light")
        self.dirnlight.setColor(Vec4(0.7,0.7,0.7,1.0))
        self.dirnlightnode = render.attachNewNode(self.dirnlight)
        self.dirnlightnode.setHpr(278,24,0)
        render.setLight(self.dirnlightnode)
        
        self.dirnlight1 = DirectionalLight("dirn_light1")
        self.dirnlight1.setColor(Vec4(1.0,1.0,1.0,1.0))
        self.dirnlightnode1 = render.attachNewNode(self.dirnlight1)
        self.dirnlightnode1.setHpr(0,347,0)
        render.setLight(self.dirnlightnode1)
        
        self.dirnlight3 = DirectionalLight("dirn_light3")
        self.dirnlight3.setColor(Vec4(0.5,0.5,0.5,1.0))
        self.dirnlightnode3 = render.attachNewNode(self.dirnlight3)
        self.dirnlightnode3.setHpr(0,347,0)
        render.setLight(self.dirnlightnode3)
        
        self.dirnlight2 = DirectionalLight("dirn_light2")
        self.dirnlight2.setColor(Vec4(0.0,0.0,1.0,1))
        self.dirnlightnode2 = render.attachNewNode(self.dirnlight2)
        self.dirnlightnode2.lookAt(self.Hook)
        self.dirnlightnode2.setH(self.dirnlightnode2.getH() + 180)
        self.dirnlightnode2.setPos(10,0,0)
        self.dirnlightnode2.setH(self.dirnlightnode2.getH() + 10)
        render.setLight(self.dirnlightnode2)
        
        self.bgSound = loader.loadSfx("sounds/Winter.mp3")
        self.bgSound.setLoop(True)
        self.bgSound.setVolume(1.0)
        self.bgSound.play()
        
        taskMgr.add(self.animate_light, "animate_light")
        taskMgr.add(self.checkBubbles, "checkBubbles")
        
    def stopLight(self):
        self.dirnlight.setColor(Vec4(0.0,0.0,0.0,1.0))
        self.dirnlight1.setColor(Vec4(0.0,0.0,0.0,1.0))
        self.dirnlight3.setColor(Vec4(0.0,0.0,0.0,1.0))
        
    def resetLight(self):
        self.dirnlight.setColor(Vec4(0.7,0.7,0.7,1.0))
        self.dirnlight1.setColor(Vec4(1.0,1.0,1.0,1.0))
        self.dirnlight3.setColor(Vec4(0.5,0.5,0.5,1.0))

    def checkBubbles(self, task):
        for i in range(BUBBLE_NOS):
            if(self.bubbles[i].getZ() > 100):
                self.bubbles[i].setPos(-100 + i * 5,0,-50)
                LerpPosInterval(self.bubbles[i], 10 * random.random(), self.bubbles[i].getPos() + Vec3(0,0,200), self.bubbles[i].getPos()).start()
                
        return task.cont
    
    def animate_light(self, task):
        self.dirnlightnode1.setH(self.dirnlightnode1.getH() + 0.5) 
        self.dirnlightnode2.setH(self.dirnlightnode2.getH() + 1)  
        self.Enviro.setH(self.Enviro.getH() + 0.02) 
            
        return task.cont    
        
    #to update the AIWorld    
    def AIUpdate(self,task):
        self.AIWorld.update()
        return Task.cont
     
    #to end the game    
    def endGame(self):
        self.request("EndGame")
    
world = GameWorld("gameworld")
#messenger.send("r",['from the messenger'])
run()
