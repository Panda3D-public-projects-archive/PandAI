
# This class was made for easy calls to the AI and scripting stuff for the 
# Egg objects

#for directx window and functions
import direct.directbase.DirectStart
from pandac.PandaModules import *

#for Actors
from direct.actor.Actor import Actor

#for Pandai
from libpandaai import *

class Character:

    def __init__(self, gameWorld, charno, mass, acc, maxforce):
        #initializing egg character
        self.gameWorld = gameWorld
        self.charno = charno
        
        self.Model = Actor("EggFile/clownfish.egg", {"swim": "EggFile/clownfish_swim.egg", "struggle": "EggFile/clownfish_struggle.egg"}) 
        self.Model.setScale(0.6)
        self.Model.setPos(-60,0,0)
        self.Model.reparentTo(render)
        
        self.dummynode = NodePath("dummy")
            
        self.AIchar = AICharacter(charno,self.Model, mass, acc, maxforce)
        self.gameWorld.AIWorld.addAiChar(self.AIchar)
        self.AIbehaviors = self.AIchar.getAiBehaviors()  
        
        self.gameOver = False
        self.pursue_start = False
        self.evade_start = False
        self.Model.loop("swim")
        self.old_force = self.AIchar.getMaxForce()
        
        #Setting the collisions
        self.collcp = CollisionSphere(0,0,3,7)
        self.collcn = CollisionNode("Seeker")
        self.collcn.addSolid(self.collcp)
        self.collcn.setFromCollideMask(BitMask32(0x8))
        self.collcn.setIntoCollideMask(BitMask32(0x8))
        self.collcnp = NodePath(self.collcn)
        self.collcnp.reparentTo(self.Model)
        #self.collcnp.show()

    ###############################SCRIPTING STUFF############################

    def distance(self, A, B):
        return((A.getPos(render) - B.getPos(render)).length())

    def proximityCheck(self, target, distance):
        self.Target = target
        self.Target_distance = distance
        taskMgr.add(self.proxChecker,"proxChecker" + self.charno)
        
    def stop_proximityCheck(self):
        taskMgr.remove("proxChecker" + self.charno)

    # checking the monsters proximity to the eggs
    def proxChecker(self,task):
        self.pursue_start = False
        if(self.distance(self.Target, self.Model) < (self.Target_distance - 1)):
            self.AIbehaviors.pursue(self.Target, 1.0)
            self.pursue_start = True
            taskMgr.remove("proxChecker" + self.charno)
            
        return task.cont

        
    ######################AI STUFF############################################
            
    def stand(self):
        self.stop()
        self.Model.play("static")

    def walk(self):
        self.stop()
        self.Model.loop("walk")
        
    def run(self):
        self.stop()
        self.Model.loop("run")
        
    def stop(self):
        self.Model.stop("walk")
        self.Model.stop("run")
    
    def place(self, pos):
        self.Model.setPos(pos)
    
    def seek(self, target, priority):
        self.AIbehaviors.seek(target,priority)
        
        
    def flee(self, target, panic_distance, relax_distance, priority):
        self.AIbehaviors.flee(target, panic_distance, relax_distance, priority)
        
    def evade(self, target, panic_distance, relax_distance, priority):
        self.evade_start = True
        self.AIbehaviors.evade(target, panic_distance, relax_distance, priority)
        
    def arrival(self, target, arrival_distance, priority):
        self.AIbehaviors.arrival(target, arrival_distance, priority)
        
    def wander(self, wander_r, flag, aoe, priority):
        self.AIbehaviors.wander(wander_r, flag, aoe, priority)
        
    def remove(self, value):
        self.AIbehaviors.removeAi(value)
        
    def status(self, ai_type):
        if(ai_type == "pursue"):
            if(self.pursue_start == True):
                if(self.AIbehaviors.behaviorStatus("pursue") == "done"):
                    return(True)
                else:
                    return(False)

        return(False)
        
    def pause(self):
        self.AIbehaviors.pauseAi("pursue")
        self.AIbehaviors.pauseAi("wander")
        self.AIbehaviors.pauseAi("evade")
        
    def resume(self):
        self.AIbehaviors.resumeAi("wander")
    