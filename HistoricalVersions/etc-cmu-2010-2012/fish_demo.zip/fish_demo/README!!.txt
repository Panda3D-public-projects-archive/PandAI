
This demo shows wander - pursue - evade

INSTRUCTIONS:

- Mouse click to use hook and fish will start pursuing you!
- If a fish is caught you will be able to move the hook with the fish around!
- All the other fishes will evade you then!
- Mouse click again to retract the hook!