Usage: meshgen <mesh_plane egg file> <mesh_collision_plane egg file>
eg: meshgen plane_mesh.egg plane_col_mesh.egg